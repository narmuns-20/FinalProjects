package springboot.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import springboot.dto.UserRegistrationDto;
import springboot.model.User;

public interface UserService extends UserDetailsService{
	User save(UserRegistrationDto registrationDto);
}
